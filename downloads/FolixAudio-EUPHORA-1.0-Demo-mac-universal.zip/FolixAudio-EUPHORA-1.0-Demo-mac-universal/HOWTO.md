# EUPHORA v1.0 — How To
**Folix Audio · Multiband Mastering Dynamics · VST3 + Standalone (Windows x64)**

EUPHORA splits your audio into 2 or 3 frequency bands, compresses each band on its own,
adds optional saturation ("Color"), then finishes with a true-peak-aware limiter.
Use it on the master bus to make a mix louder, glued and controlled, or on a drum, bass or vocal bus.

---

## 1. Install

### VST3 (FL Studio, Ableton, Bitwig, Reaper, Cubase, Studio One…)
1. Unzip `EUPHORA-1.0-FOLIX-win.vst3.zip`.
2. Copy the `EUPHORA.vst3` folder to `C:\Program Files\Common Files\VST3\`.
3. Rescan plugins in your DAW.
   - **FL Studio:** Options → Manage plugins → *Find more plugins*. It shows up as **EUPHORA** by **Folix Audio** (effect).
4. Put it on a mixer insert, usually the **last** slot on the master.

### Standalone
Run `FolixAudio-EUPHORA-v1.0.exe`. Use the Options/settings button to pick your audio device and input.
It's handy for quick listening tests. For real work, use the VST3 in your DAW.

> Windows may show a SmartScreen warning because the files are not code-signed yet. Click *More info → Run anyway*.

---

## 2. Signal flow
```
INPUT → crossover (2 or 3 bands) → per-band compressor → MIX (parallel, phase-matched dry)
      → COLOR saturation → limiter PUSH → SOFT CLIP (optional) → LIMITER (CEILING) → TRIM
```
Color, Push and Soft Clip run inside the optional 2x/4x oversampling.

---

## 3. 2-band vs 3-band (GLOBAL → BANDS)
| Mode | Bands | Use it for |
|---|---|---|
| **2 BANDS** | LOW / HIGH, one split (default 160 Hz) | Drum buses, sidechain-style pumping, podcasts, simple "lows vs everything else" control |
| **3 BANDS** | LOW / MID / HIGH, two splits (default 160 Hz and 2.8 kHz) | Full mixes and masters, where you want to control the bass, body and air separately |

**Move the splits** by dragging the glowing handles at the top of the spectrum.
The crossovers (Linkwitz-Riley) sum flat, so with nothing compressing, EUPHORA does not color the sound.

---

## 4. Controls

### Header
- **< Preset >**: steps through the factory and user presets. Click the name to open the list.
- **SAVE**: saves a user preset to `Documents\Folix Audio\EUPHORA Presets\` as a `.euphora` file.
- **OVERSAMPLE**: OFF / 2X / 4X. Use 2X or 4X when you drive Color, Push or Soft Clip hard. It reduces aliasing and adds a little latency, which your DAW compensates for.
- **MATCH + BYPASS**: with MATCH on, BYPASS plays the dry signal at the *same loudness* as the processed one, so you hear what EUPHORA really does and not just "louder".

### Spectrum and meters
- The bright line is the output and the grey ghost line is the input. The curtains at the top show each band's gain reduction.
- **LOUDNESS**: short-term LUFS (3 s window), IN vs OUT gain, input and output peak meters, and limiter GR.

### Each band (LOW / MID / HIGH)
| Control | What it does |
|---|---|
| **MODE** | **CLEAN**: transparent peak compression. **OPTO**: smooth, program-dependent release, good for vocals and masters. **PUNCH**: fast with a hard knee, lets the transient through first, good for drums. **GLUE**: RMS with a wide knee and auto release, good for gluing a mix together. |
| **FOCUS** | **ALL** (normal), **MID** only or **SIDE** only. MID/SIDE focus works best with GLOBAL set to MID/SIDE. |
| **THRESHOLD** | Level where compression starts. Lower means more compression. |
| **RATIO** | How hard it compresses (1:1 = off, 20:1 = limiting). |
| **ATTACK / RELEASE** | How fast it clamps down and lets go. |
| **KNEE** | Soft (high) vs hard (low) onset. |
| **MAKEUP** | Gain after compression for that band. |
| **SOLO / BYPASS** | Listen to one band alone, or switch a band's compressor off. |
| GR meter | Gain reduction for the band. |

### GLOBAL
- **BANDS**: 2 or 3.
- **STEREO / MID/SIDE**: process L/R linked, or Mid and Side independently.
- **DETECTOR HPF**: stops sub bass from triggering the compressor (20 Hz = off). Try 60–120 Hz on bass-heavy material.
- **INPUT**: input gain into the whole chain.

### COLOR
- **DRIVE**: saturation amount.
- **CHARACTER**: **WARM** (asymmetric, even harmonics, thicker) or **TAPE** (symmetric, softer highs).
- **DRIVE ON GR**: adds extra drive when the bands are compressing, so loud parts get grittier.

### LIMITER
- **LIMIT**: limiter on/off. **SOFT CLIP**: rounds peaks off before the limiter for extra loudness and a little edge.
- **PUSH**: drives into the limiter. This is your main loudness knob.
- **CEILING**: maximum output level, true-peak aware (default −0.1 dBFS). Use −1.0 dBFS for streaming.
- **RELEASE**: limiter recovery. Shorter is louder and more aggressive. Longer is cleaner.

### OUTPUT
- **MIX**: parallel blend of dry vs compressed bands (New-York-style compression below 100%).
- **TRIM**: final attenuation only, so it can never push past the ceiling.

---

## 5. Presets (27 factory)
- **INIT**: neutral starting point.
- **MASTER**: Master Glue, Gentle Polish, Loud EDM, Club Master, Transparent Limit, Streaming Safe, Wide Air Lift, Synthwave Haze, Cinematic Swell
- **BEATS**: Punchy Drums, Drum Bus Smash, Parallel Crush, Kick Snap, House Bounce, Hi-Hat De-Harsh, Future Bass Pump
- **BASS**: Bass Tighten, Mono Bass Focus, Trap 808 Control, Dubstep Wall
- **VOCAL**: Vocal Bus, Pop Vocal Shine, Podcast Leveler, Acoustic Sheen, Side Tamer, Lo-Fi Tape Warmth

User presets live in `Documents\Folix Audio\EUPHORA Presets\` and can be shared as `.euphora` files.

---

## 6. Quick start (master bus)
1. Load **Master Glue** (gentle) or **Club Master** (louder).
2. Play the loudest part of your track. Raise **PUSH** until the LOUDNESS readout hits your target
   (around −14 LUFS short-term for streaming, −9 to −7 for club or dubstep).
3. Turn on **MATCH** and toggle **BYPASS**. If the bypassed version sounds better at equal loudness, back off.
4. Set **CEILING** to −1.0 dB if the track is going to streaming services.

## 7. Tips
- **Dubstep / bass music:** start from **Dubstep Wall**, set OVERSAMPLE to 4X, and pull **LOW → THRESHOLD** up if the sub starts pumping.
- **Mono sub:** **Mono Bass Focus** keeps the low band centered and tames wide sub energy.
- **Harsh hats or cymbals:** **Hi-Hat De-Harsh**, then fine-tune the high split (x2) with the handle.
- **Pumping groove:** 2 BANDS + GLUE mode + a slow release (250–300 ms), as in **Future Bass Pump**.
- **Parallel punch:** crank the ratios, then bring **MIX** down to 30–60% (**Parallel Crush**).
- **Check single bands:** SOLO a band while you set its threshold. You'll hear exactly what it is grabbing.
- **Watch the GR meters:** 2–4 dB per band is "glue". Past 8 dB is an effect.
- **Don't fight the limiter:** if LIM GR keeps going past 6 dB, lower PUSH and compress the bands a bit more instead.

## 8. Demo
`EUPHORA-1.0-demo.wav` (30 s, 48 kHz / 24-bit stereo) plays the same 128 BPM loop four times:
**DRY** (−6 dBFS peak) → **Gentle Polish** → **Club Master** → **Dubstep Wall**. Each preset uses a −1.0 dB ceiling,
so you can hear the progression from untouched to fully slammed.

---
© 2026 Folix Audio. Build instructions are in `README.md`.

## macOS

- Install `EUPHORA.vst3` into `~/Library/Audio/Plug-Ins/VST3/` and `EUPHORA.component` (Audio Unit, for Logic and GarageBand) into `~/Library/Audio/Plug-Ins/Components/`.
- On macOS the licence and user presets live in `~/Library/Application Support/Folix Audio/` (`EUPHORA/license.folixlic` and `EUPHORA Presets/`), not in Documents. This avoids the macOS "allow access to Documents" prompt inside your DAW.
- If the build isn't notarized, run `xattr -dr com.apple.quarantine` on the installed plug-in once (see MAC-INSTALL.txt).
