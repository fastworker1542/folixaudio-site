# DROP v2.2 by Folix Audio: How To

DROP is a mono-friendly sub-bass and dubstep bass synth. You get a clean SUB oscillator, a harmonic LAYER for growls, a GROWL page (fold, warp, FM, formant, comb), a modulation matrix, and a serial FX rack. A -1 dBFS safety limiter sits at the end.

---

## 1. Install (Windows VST3)

1. Close FL Studio.
2. Unzip `DROP-2.2-FOLIX-win.vst3.zip`. You'll get `DROP.vst3`, a folder bundle.
3. Copy the whole `DROP.vst3` folder to:
   `C:\Program Files\Common Files\VST3\`
4. If you had the old Starlace Audio build installed, delete that `DROP.vst3` first so you don't end up with two copies.

## 2. Load in FL Studio

1. Open FL Studio and go to **Options > Manage plugins**, then click **Find installed plugins** (or **Find more plugins**).
2. Look for **DROP** under the manufacturer **Folix Audio** and tick the star to make it a favourite.
3. Go to **Channel rack > + (Add) > DROP**, or drag it from the plugin browser.
4. Open the Piano roll on the DROP channel and write notes. C1 (MIDI 24) to C2 (MIDI 36) is the sub sweet spot.
5. To get synced wobbles, play the project. LFO and Function sync follow FL's tempo. With no host tempo, DROP uses 120 BPM.

> The new build is Folix Audio DROP, with new plugin IDs. FL projects saved with the older Starlace Audio DROP won't swap to this one automatically. Load the new DROP and pick the same preset again, or keep the old build installed for those projects.

## 3. Layout

| Area | What it does |
|---|---|
| **Preset browser** (left) | Categories: ALL, SUB, 808, REESE, GROWL, WOBBLE, PLUCK, KEYS, USER. Use `<` and `>` to step through presets. |
| **SAVE** | Saves a user preset to `Documents\Folix Audio\DROP Presets\*.dropx`. It shows up under **USER**. |
| **Tabs** | **SYNTH**, **GROWL**, **MOD**, **FX** |
| **EQ / STEREO / OUT** (always visible) | Limiter, Low and High EQ, MONO < (everything below this frequency is mono), WIDTH, OUTPUT |

## 4. Voice modes (SYNTH > VOICE)

- **MODE**
  - **Poly**: chords and stacked notes.
  - **Mono**: one note at a time, and every note retriggers.
  - **Legato** (default): overlapping notes slide without retriggering the envelope. This is the classic sub and wub behaviour. Releasing a key falls back to the note that's still held.
- **GLIDE MODE**: Off, Always, or Legato (glide only when notes overlap). **GLIDE** sets the glide time.
- **VEL**: how much velocity affects level.
- **BEND**: pitch-bend range in semitones.
- **TUNE**: fine tune.

Other SYNTH panels:
- **SUB**: Sine, Round, Triangle, Warm Saw or Soft Square, each with an octave. Phase reset gives consistent transients.
- **HARMONICS** (the layer): Classic, Additive or Reese engine, with wave (Saw, Square, Pulse, Triangle or Sine), octave, semi, fine, level, unison, detune, width and morph.
- **ADDITIVE PARTIALS**: draw partials or use the SAW, SQR, ORGAN and RAND buttons, plus tilt, odd/even and stretch.
- **TEXTURE**: noise (White, Hiss, Crackle) and ring mod.
- **FILTER**: 12 or 24 dB slope, cutoff, resonance, envelope, decay and key-track. **SUB THRU** (Filter Sub Too) sends the sub through the filter as well. Leave it off for a clean sub.
- **AMP**: ADSR plus PUNCH.
- **808 DROP + CLICK**: pitch drop amount and time, plus click level and tone.

## 5. Growl tools (GROWL tab)

- **GROWL SOURCE**: Growl Sub (feeds the sub into the growl chain), FOLD (wavefolder), WARP (phase distortion), FM amount and FM RATIO.
- **FORMANT (A-E-I-O-U)**: VOWEL position, SHIFT, Q and MIX. This is the "yoi" and talking sound.
- **COMB**: key-tracked comb filter with MIX, RATIO, FEEDBACK and DAMP, for metallic and robotic tones.
- **MOVEMENT (FUNCTION 1)**: draw a custom shape or pick Ramp, Triangle, Sine, Square, Wobble or Stairs. Set the sync rate (1/1 to 1/32, including triplets) and the mode (Retrig, Free or One-Shot).
- **QUICK GROWL**: one click assigns Function 1 to a growl destination:
  - **VOWEL WOBBLE**: formant vowel sweep
  - **FM YOY**: FM amount
  - **COMB SWEEP**: comb mix
  - **SUB GROWL**: fold, plus sub regen
- **TONE**: harmonics engine, layer level, morph, cutoff and resonance.
- **SUB REGEN**: rebuilds a clean sine sub under the growl after all the distortion, using the crossover and follow controls.

## 6. Macros

The four macros on the GROWL page are **GROWL, VOWEL, SNARL and DEPTH**. They don't do anything until you route them. In **MOD > MOD MATRIX**, pick `Macro GROWL` (or another macro) as a **Source**, choose a **Destination** and set the amount. Then automate the macro knob in FL: right-click it and choose **Create automation clip**. One knob can then move several growl parameters during a drop.

Here's a good starting setup:
- GROWL to Fold (+0.5) and Drive (+0.3)
- VOWEL to Vowel (+0.8)
- SNARL to FM Amount (+0.5) and Comb Feedback (+0.3)
- DEPTH to Cutoff (+0.6)

## 7. Modulation (MOD tab)

- **FUNCTION 1 and 2**: drawable, tempo-synced function generators. These are the main wobble engines.
- **LFO 1**: Sine, Triangle, Square or Random. It's free-running or synced, and goes straight to Pitch, Cutoff, Layer Level, Drive or Volume.
- **LFO 2 + RANDOM**: a second LFO and a random-rate control.
- **MOD MATRIX**: 8 slots, each with a Source, a Destination and an Amount.
  - Sources: Func 1 and 2, LFO 1 and 2, Note Random, Drift Random, Mod Wheel, Velocity, and the four macros.
  - Destinations: Cutoff, Resonance, Morph, Tilt, Odd/Even, Stretch, Drive, Layer Level, Pitch, Noise, Ring, Layer Width, Volume, Sub Proc, Rack Filter, Vowel, Formant Shift, FM Amount, Fold, Warp, Comb Mix, Comb Feedback and Growl Sub.
- **QUICK WOBBLE**: one-click 1/8 wobble from Function 1 to Cutoff.

## 8. FX (FX tab)

- **DRIVE**: Tape, Tube, Clip or Fold, with mix and **SUB SEND**. It's 2x oversampled and runs in parallel. The sub only gets driven as much as SUB SEND allows.
- **SUB PROCESSOR**: Warm, Tape, Tube, Clip, Fold, Octaver, Punch, Squash, Excite, Widen Up or Growl Up.
- **CHORUS / COMP**
- **FX RACK**: 8 serial slots that run left to right. Pick a module in each slot and click the slot number to edit it. Modules:
  - **MB Comp**, **Para EQ**, **Distort** (Warm, Hard, Fold or Rectify, 2x oversampled), **Crush**
  - **Unison Chorus**, **Phaser**, **Flanger**, **Delay** (synced), **Reverb**
  - **Filter** (LP, HP or BP, and you can modulate it with Rack Filter)
  - **OTT** (3-band upward and downward compression)
- **SUB REGEN** (clean sub after FX) and **MAXIMIZER** (Soft or Hard, with gain).

## 9. Presets

There are 88 factory presets in these categories: SUB, 808, REESE, GROWL, WOBBLE, PLUCK and KEYS. Good starting points:

- **Pure sub**: `SUB / Deep Pure`, `Round Floor`, `Punch Floor`
- **Wubs**: `WOBBLE / Eighth Wobble`, `Triplet Yoy`, `Owl Mouth 1-4`, `Yo Yo Pit`
- **Growls**: `GROWL / Growl Sub`, `Fold Snarl`, `Basement Snarl`, `Neuro Knot`, `OTT Grizzly`, `Velvet Gnarl`
- **Reese**: `REESE / Moving Reese`, `Reese Gnash`

## 10. MIDI

- **Notes**: Legato mode slides overlapping notes. Write a slight overlap in FL's piano roll to get a glide.
- **Pitch bend**: the range is set by **BEND** on the VOICE panel.
- **Mod wheel (CC1)**: use it as a source in the mod matrix. A common setup is Mod Wheel to Vowel or Cutoff, played live.
- **Velocity**: this is also a matrix source, for example Velocity to Fold for harder hits.
- **Automation**: every knob can be automated from FL, including the macros and the FX slot types.

## 11. Dubstep tips

**Clean subs**
- Start from `SUB / Deep Pure`, set MODE to Legato and keep the sub in C1 to G1.
- Keep **SUB THRU** off and DRIVE SUB SEND low.
- Set **MONO <** to about 120 Hz.
- Leave the limiter on. DROP already caps the output at -1 dBFS.
- Sidechain the kick in FL with Fruity Limiter or a ducking tool, rather than overdriving the sub.

**Wubs**
- Use QUICK WOBBLE or a WOBBLE preset, and set Function 1's sync to 1/8 for classic wubs, 1/8T for the triplet "yoy", or 1/4 and 1/2 for slow growls.
- Automate the Function 1 **Sync** between bars to switch rhythm in the middle of a phrase. That's the classic call and response.
- Use VOWEL WOBBLE instead of a cutoff wobble for a talking "yoi" sound.

**Growls**
- Use FOLD plus FM for grit, the formant filter for the vowel, then OTT and Distort in the rack.
- Always turn on **SUB REGEN** so the low end stays solid underneath.
- Layer two DROP instances: one pure sub at -1 octave, and one growl with the low end cut.

**Mix**
- Set a high-pass (rack Filter in HP mode) around 80 to 100 Hz on the growl instance.
- Keep WIDTH low on anything with sub content.
- Check in mono.

## 12. Building from source

See `README.txt`. In short: `cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --target DROP_VST3` (JUCE 8). The Windows cross-build uses `tools/clang-cl-xwin.cmake`.

(c) 2026 Folix Audio

## macOS

- Install `DROP.vst3` into `~/Library/Audio/Plug-Ins/VST3/` and `DROP.component` (Audio Unit, for Logic and GarageBand) into `~/Library/Audio/Plug-Ins/Components/`.
- On macOS the licence and user presets live in `~/Library/Application Support/Folix Audio/` (`DROP/license.folixlic` and `DROP Presets/`), not in Documents. This avoids the macOS "allow access to Documents" prompt inside your DAW.
- If the build isn't notarized, run `xattr -dr com.apple.quarantine` on the installed plug-in once (see MAC-INSTALL.txt).
